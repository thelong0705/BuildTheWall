For windows user:
To play this game you need to download and install the Java Runtime Environment (if you do not have it already) from the link below.
https://www.java.com/en/download/
Once downloaded, you can play the game by double clicking the jar file. 

For linux user:
cd into the folder contains the BuildTheWall.jar
You'll need to use the java command to run a .jar file: java -jar BuildTheWall.jar
if you dont have java you can install with apt-get install default-jdk

